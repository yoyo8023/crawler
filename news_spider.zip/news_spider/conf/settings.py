# coding:utf8

# ACCESSKEYID = 'tyifZyIuXocfXvnf'
# ACCESSKEYSECRET = 'gT7e2D1RmoRZnWyswlxnRJ0w3qQ2SI'
# ENDPOINT = 'http://oss-cn-hangzhou.aliyuncs.com'
# BUCKET_NAME = 'hcmtest'
#
# STATIC_URL = 'http://hcmtest.oss-cn-hangzhou.aliyuncs.com/'


DATABASES = {
    'NAME': 'hcm',
    'USER': 'hcm_news_spider',
    'PASSWORD': 'PjIxnE9DauD1JC34',
    'HOST': '121.41.29.114',
    'PORT': 3306,
}

OSS = {
    'ACCESSKEYID': 'tyifZyIuXocfXvnf',
    'ACCESSKEYSECRET': 'gT7e2D1RmoRZnWyswlxnRJ0w3qQ2SI',
    'ENDPOINT': 'http://oss-cn-hangzhou.aliyuncs.com',
    'BUCKET_NAME': 'huochuanmei',
    'STATIC_URL': 'http://static.huo.com/'
}


