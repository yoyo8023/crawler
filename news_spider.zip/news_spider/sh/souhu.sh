#!/usr/bin/env bash
python /home/prod/deploys/crawler/news_spider/manage.py souhu